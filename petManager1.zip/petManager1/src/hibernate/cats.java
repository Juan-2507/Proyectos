package hibernate;


import java.util.Scanner;
import maping.Cat;
import maping.Pet;

public class cats {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        int tipo;
        String sino;
        
        cat model = new cat();

        Pet p = new Pet("002", "Nieves", 2020, "Blanco", "Buena salud");
        Cat c = new Cat(p, "criollo");

        System.out.println("¿Qué desea hacer?:");
        System.out.println("1. Crear");
        System.out.println("2. Eliminar");
        System.out.println("3. Actualizar");
        System.out.println("4. Mostrar");

        tipo = teclado.nextInt();

        switch (tipo) {
            case 1 -> model.create(p, c);
            case 2 -> {
                System.out.println("Ingrese el código");
                String code = teclado.next();
                if (code != null) {
                    model.Eliminar(code);
                }
            }
            case 3 -> {
                System.out.println("Ingrese el código");
                String codeAct = teclado.next();
                System.out.println("Ingrese el año a actualizar");
                int año = teclado.nextInt();
                model.Actualizar(codeAct, año);
            }
            case 4 -> {
                System.out.println("Ingrese el código");
                String codeMostrar = teclado.next();
                model.mostrar(codeMostrar);
            }
            default -> System.out.println("Opción no válida");
        }

        System.out.println("¿Desea realizar alguna otra opción? (S/N): ");
        sino = teclado.next();
        if (sino.equalsIgnoreCase("S")) {
            // Agrega el código necesario si el usuario desea realizar otra opción
        }

    }
}
