package hibernate;

import maping.Pet;
import maping.Cat;
import Hibernate_archivos.NewHibernateUtil;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class cat {

    public void create(Pet p, Cat c) {
        try (SessionFactory sessionFactory = NewHibernateUtil.getSessionFactory();
             Session session = sessionFactory.openSession()) {
            Transaction t = session.beginTransaction();
            session.save(p);
            session.save(c);
            t.commit();
            System.out.println("Creado correctamente");
        } catch (Exception e) {
            System.out.println("Error al crear: " + e.getMessage());
        }
    }

    public void mostrar(String id) {
        try (SessionFactory sessionFactory = NewHibernateUtil.getSessionFactory();
             Session session = sessionFactory.openSession()) {
            Pet s = session.get(Pet.class, id);
            Cat s1 = session.get(Cat.class, id);
            if (s != null && s1 != null) {
                System.out.println("Id: " + s.getPetCode());
                System.out.println("Name: " + s.getPetName());
                System.out.println("HealthStatus: " + s.getPetHealthStatus());
                System.out.println("Color: " + s.getPetColor());
                System.out.println("born year: " + s.getPetBornYear());
                System.out.println("breed: " + s1.getCatBreed());
            } else {
                System.out.println("No se encontró la mascota con el ID proporcionado");
            }
        } catch (Exception e) {
            System.out.println("Error al mostrar: " + e.getMessage());
        }
    }

    // Métodos actualizar y eliminar similares a los proporcionados anteriormente

    void Eliminar(String code) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void Actualizar(String codeAct, int año) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
