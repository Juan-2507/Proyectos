package petManager;

import Class.clscat;
import Class.clsdog;
import Class.clspet;
import Class.clsveterinary;
import java.util.Date;

public class petManager {

    public static void main(String[] args) {
        // Crear instancias de las clases para representar mascotas y veterinario
        clsdog pet1;
        clscat pet2;
        clsveterinary huellita;

        // Inicializar mascota 1 (perro)
        pet1 = new clsdog();
        pet1.setCode("001");
        // Asignar valores para pet1 (perro)
        pet1.setName("Pulgas");
        pet1.setBreed("Golden Retriever");
        pet1.setBorn_year(2021);
        pet1.setPedigri(true);
        pet1.setColor("Amarillo");
        pet1.setHealthStatus("Buena salud");

        // Inicializar mascota 2 (gato)
        pet2 = new clscat("criollo", "002", "Nieves", 2020, "Blanco", "Buena salud");

        // Inicializar veterinario
        huellita = new clsveterinary();

        // Imprimir información y realizar acciones de las mascotas
        System.out.println("Información de mascota 1 (perro):");
        System.out.println(pet1);
        pet1.walkAround();
        pet1.Eat();
        pet1.Move();
        pet1.Sound();

        System.out.println("\nInformación de mascota 2 (gato):");
        System.out.println(pet2);
        pet2.selfCleaning();
        pet2.Eat();
        pet2.Move();
        pet2.Sound();

        // Llamar al método Date con pet1 y pet2
        Date(pet1, pet2);

        // Realizar cuidado de mascotas por parte del veterinario
        huellita.petCare(pet1);
    }

    // Método para calcular la diferencia de edad entre dos mascotas
    public static void Date(clspet PET1, clspet PET2) {
        Date current_date = new Date();
        int current_year = current_date.getYear() + 1900; // Ajuste para obtener el año actual

        int PT1 = current_year - PET1.getBorn_year();
        int PT2 = current_year - PET2.getBorn_year();
        
        if (PT1 > PT2) {
            System.out.println("La mascota " + PET1.getName() + " es mayor que la mascota " + PET2.getName());
        } else if (PT1 < PT2) {
            System.out.println("La mascota " + PET1.getName() + " es menor que la mascota " + PET2.getName());
        } else {
            System.out.println("Ambas mascotas son de la misma edad.");
        }
    }
}
